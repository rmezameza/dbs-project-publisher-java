create PROCEDURE buchautor (autorid IN NUMBER, autor_full_name OUT VARCHAR2) AS
    BEGIN
        SELECT au_vorname || ' ' || au_nachname INTO autor_full_name FROM autor
            WHERE autorid = autor_id;
    END;
/

