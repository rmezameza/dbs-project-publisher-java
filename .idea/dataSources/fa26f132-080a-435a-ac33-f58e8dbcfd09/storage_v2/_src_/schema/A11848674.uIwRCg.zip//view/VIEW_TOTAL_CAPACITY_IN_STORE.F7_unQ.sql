create view VIEW_TOTAL_CAPACITY_IN_STORE as
SELECT SUM(r.regal_kapazitaet) AS gesamtkapazitaet, r.lag_id, l.lag_strasse, l.lag_plz, l.lag_ort
    FROM regal r
        INNER JOIN buchlager l ON r.lag_id = l.lag_id
    GROUP BY (r.lag_id, l.lag_strasse, l.lag_plz, l.lag_ort)
/

