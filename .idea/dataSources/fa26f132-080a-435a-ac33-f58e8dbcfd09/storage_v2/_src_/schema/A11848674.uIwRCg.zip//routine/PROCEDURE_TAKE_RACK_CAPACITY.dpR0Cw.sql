create PROCEDURE procedure_take_rack_capacity (rack_nr IN NUMBER, bookstore_id IN NUMBER, rack_cap OUT NUMBER) IS
    BEGIN
        SELECT regal_kapazitaet INTO rack_cap FROM regal WHERE regal_nr = rack_nr AND lag_id = bookstore_id;
    END;
/

