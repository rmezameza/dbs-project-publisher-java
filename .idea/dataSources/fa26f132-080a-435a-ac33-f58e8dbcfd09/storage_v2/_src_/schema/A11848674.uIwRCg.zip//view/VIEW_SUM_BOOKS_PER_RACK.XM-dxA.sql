create view VIEW_SUM_BOOKS_PER_RACK as
SELECT SUM(stueck) as summe_buecher_regal, lag_id, regal_nr FROM gelagert
        GROUP BY (lag_id, regal_nr)
/

