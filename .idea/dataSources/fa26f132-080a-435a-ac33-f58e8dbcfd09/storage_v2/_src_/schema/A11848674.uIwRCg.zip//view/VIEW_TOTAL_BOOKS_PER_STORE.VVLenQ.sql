create view VIEW_TOTAL_BOOKS_PER_STORE as
SELECT SUM(g.stueck) AS gesamtbuecher, g.lag_id, l.lag_strasse, l.lag_plz, l.lag_ort
    FROM gelagert g
        INNER JOIN buchlager l ON g.lag_id = l.lag_id
    GROUP BY (g.lag_id, l.lag_strasse, l.lag_plz, l.lag_ort)
/

