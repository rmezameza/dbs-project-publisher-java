create view VIEW_AUTHORS_SORTED_BY_SURNAME as
SELECT autor_id, au_vorname, au_nachname, bio FROM autor
/

