create trigger TRIGGER_LAG_ID
    before insert
    on BUCHLAGER
    for each row
DECLARE
            seq_bl_id   buchlager.lag_id%type;
        BEGIN
            SELECT seq_lag_id.nextval INTO seq_bl_id FROM dual;
            :new.lag_id := seq_bl_id;
        END;
/

