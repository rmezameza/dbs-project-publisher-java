create PROCEDURE procedure_find_genre (book_genre IN VARCHAR2, bookstore_id IN NUMBER, rack_nr OUT NUMBER) IS
    BEGIN
        SELECT regal_nr INTO rack_nr FROM regal WHERE regal_name = book_genre AND lag_id = bookstore_id;
    END;
/

