create view VIEW_BOOKS_FOR_AUTHOR as
SELECT buch_id, titel, cover FROM buch
        NATURAL JOIN schreibt
        NATURAL JOIN autor
/

