create view VIEW_GEHALT_RAHMEN as
SELECT ma_id, sv_nr, ma_vorname, ma_nachname, gehalt
        FROM intern
            NATURAL JOIN mitarbeiter
    HAVING (MIN(GEHALT) < 1600 OR MAX(GEHALT) > 2200)
    GROUP BY (ma_id, sv_nr, ma_vorname, ma_nachname, gehalt)
/

