create trigger TRIGGER_KRITIKER_ID
    before insert
    on BUCHKRITIKER
    for each row
DECLARE
            seq_bk_id   buchkritiker.kritiker_id%type;
        BEGIN
            SELECT seq_kritiker_id.nextval INTO seq_bk_id FROM dual;
            :new.kritiker_id := seq_bk_id;
        END;
/

