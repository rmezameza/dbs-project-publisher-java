create view VIEW_AUTHORS_FOR_BOOK as
SELECT autor_id, au_nachname, au_vorname, buch_id FROM autor
    NATURAL JOIN schreibt
    NATURAL JOIN buch
/

