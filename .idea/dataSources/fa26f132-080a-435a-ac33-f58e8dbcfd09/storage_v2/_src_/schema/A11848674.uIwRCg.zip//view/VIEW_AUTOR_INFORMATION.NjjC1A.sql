create view VIEW_AUTOR_INFORMATION as
SELECT buch_id, b.isbn, b.titel, b.cover, a.au_vorname, a.au_nachname, autor_id
FROM autor a
         NATURAL JOIN schreibt
         NATURAL JOIN buch b
/

