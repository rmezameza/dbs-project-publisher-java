create PROCEDURE procedure_concatenate_author_name (author_id IN NUMBER, full_name OUT VARCHAR2) IS
    BEGIN
        SELECT au_vorname || ' ' || au_nachname INTO full_name FROM autor WHERE autor_id = author_id;
    END;
/

