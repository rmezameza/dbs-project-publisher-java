create view VIEW_BOOKSTORE_JOINS_VBS_CAPSTATUS as
SELECT bl.lag_id, bl.lag_strasse, bl.lag_plz, bl.lag_ort, bl.lag_land,
           vbscs.gesamtkapazitaet, vbscs.gesamtbuecher
    FROM buchlager bl
        LEFT OUTER JOIN view_book_store_capacity_status vbscs ON bl.lag_id = vbscs.lag_id
/

