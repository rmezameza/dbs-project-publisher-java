create view VIEW_COUNT_BOOKS_FOR_GENRES as
SELECT COUNT(genre) AS buchanzahl, genre
    FROM buch
    GROUP BY genre
/

